export interface ThemeOption {
  id: string;
  name: string;
  color: string;
}

export const themes: ThemeOption[] = [
  { id: "dark", name: "Dark", color: "#000000" },
  { id: "light", name: "Light", color: "#FFFBFE" },
];