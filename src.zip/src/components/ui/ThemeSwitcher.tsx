'use client'

import { useState, useRef, useEffect } from "react";
import { MdPalette, MdCheck } from "react-icons/md";
import { useTheme } from "next-themes";
import { themes } from "../../data/theme";
import { useMounted } from "../../hooks/useMounted";

export function ThemeSwitcherDesktop() {
  const { theme, setTheme } = useTheme();
  const [open, setOpen] = useState<boolean>(false);
  const mounted = useMounted();
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  if (!mounted) return null;

  const activeTheme = themes.find((t) => t.id === theme);

  return (
    <div className="relative hidden tablet:block" ref={ref}>
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2 bg-surface-hover hover:bg-surface p-2 rounded-full border border-border transition duration-200 cursor-pointer"
      >
        <MdPalette size={16} className="text-text-secondary" />
        <span
          className="w-4 h-4 rounded-full border border-border"
          style={{ backgroundColor: activeTheme?.color }}
        />
      </button>

      {open && (
        <div className="absolute right-0 mt-2 w-48 bg-surface border border-border rounded-2xl p-2 shadow-lg shadow-black/30 z-50">
          {themes.map((t) => (
            <button
              key={t.id}
              onClick={() => {
                setTheme(t.id);
                setOpen(false);
              }}
              className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-sm text-text-secondary hover:bg-surface-hover hover:text-text-primary transition duration-150 cursor-pointer"
            >
              <span
                className="w-4 h-4 rounded-full border border-border shrink-0"
                style={{ backgroundColor: t.color }}
              />
              <span className="flex-1 text-left">{t.name}</span>
              {theme === t.id && <MdCheck size={14} className="text-primary" />}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export function ThemeSwitcherMobile() {
  const { theme, setTheme } = useTheme();
  const mounted = useMounted();

  if (!mounted) return null;

  return (
    <div className="flex items-center gap-3 px-4 py-3">
      {themes.map((t) => (
        <button
          key={t.id}
          onClick={() => setTheme(t.id)}
          className={`w-8 h-8 rounded-full border-2 transition duration-200 cursor-pointer active:scale-90 ${
            theme === t.id ? "border-primary scale-110" : "border-border"
          }`}
          style={{ backgroundColor: t.color }}
        />
      ))}
    </div>
  );
}