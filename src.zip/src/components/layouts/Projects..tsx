"use client"
import Image from "next/image";
import { StaticImageData } from "next/image";
import { FaGithub, FaGlobe } from "react-icons/fa";
import { useTranslation } from "react-i18next";
import { supabase } from "@/lib/supabase"
import Link from "next/link";
import { useEffect, useState } from "react";
import { BsBoxSeamFill } from "react-icons/bs";
import { BiDetail } from "react-icons/bi";
import { PiDetective } from "react-icons/pi";

interface Project {
    id: number;
    name: string;
    category: string;
    description: string;
    image: StaticImageData | string;
    tech: string[];
    demo_link?: string;
    githubLink?: string;
    link?: string;
}

// const projects: Project[] = [
//     {
//         id: 1,
//         title: "Project AxVision",
//         category: "TOOLS",
//         description:
//             "Tools Android system optimizer yang saya kembangkan sendiri sebagai solo developer. Mengoptimalkan performa sistem Android yang dikenal berat dan boros RAM, terutama di perangkat Xiaomi/POCO/Redmi/Infinix/TECNO.",
//         image: "/img/axvision_hawk.webp",
//         tags: ["Bash", "JavaScript", "Android", "Root", "KernelSU", "AxManager", "KernelSU API", "Vite.js", "React"],
//         customLink: "https://www.magiskmodule.com/axvision",
//     },
//     {
//         id: 2,
//         title: "Website Game Corner",
//         category: "WEB",
//         description:
//             "Project perdana saya yang merangkum semua skill yang sudah dipelajari. Website untuk aplikasi di Play Store milik teman/guru yang jadi salah satu orang pertama yang mengajarkan saya coding.",
//         image: "/img/red_corner_project.webp",
//         tags: ["React", "JavaScript", "Vite.js", "Tailwind CSS", "Play Store Scraper API", "Firebase"],
//         liveUrl: "https://debug.game-corner.pages.dev/",
//     },
//     {
//         id: 3,
//         title: "Website AxManager Society",
//         category: "WEB",
//         description:
//             "Dikembangkan dari tugas sekolah Pak Tri Gunawan. AxManager adalah tools Android untuk modifikasi ringan (non-root) maupun berat (root). Saya jadi salah satu plugin developer di aplikasi ini (5 plugin, 3 di antaranya sudah tidak mendapat update). Website ini mengenalkan AxManager ke pengguna baru dan komunitas.",
//         image: "/img/axmanager_society.webp",
//         tags: ["React", "JavaScript", "Vite.js", "Tailwind CSS", "Play Store Scraper API", "Firebase"],
//         liveUrl: "https://debug.game-corner.pages.dev/",
//     },
//     {
//         id: 4,
//         title: "Project Qiunix",
//         category: "TOOLS",
//         description:
//             "Tools Android system optimizer yang saya kembangkan sendiri sebagai solo developer. Mengoptimalkan performa sistem Android yang dikenal berat dan boros RAM, terutama di perangkat Xiaomi/POCO/Redmi/Infinix/TECNO.",
//         image: "/img/qiunix_apollo.webp",
//         tags: ["Bash", "JavaScript", "Android", "Root", "KernelSU", "AxManager", "KernelSU API", "Vite.js", "React"],
//         customLink: "https://www.magiskmodule.com/qiunix-apollo",
//     },
// ];

export default function Projects() {
    const {t} = useTranslation()
    const [projects, setProjects] = useState<Project[]>([]);

    useEffect(() => {
        async function load() {
            try {
                const { data } = await supabase.from('projects').select('*');

                setProjects(data ?? [])
            } catch (error) {
                console.log(error)
            }
        }

        load()
    }, [])

    return (
        <section id="proyek" className="px-6 py-20 md:px-10 md:py-28 border-t">
            <div className="mb-10">
                <h2 className="text-3xl font-bold">{t("techStack.title")}</h2>
                <p className="text-sm mt-4 text-muted/80 max-w-110">{t("techStack.desc")}</p>
            </div>
            { projects.length > 0 ?
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {projects.map((project) => (
                        <ProjectCard key={project.id} project={project} />
                    ))}
                </div>
                :
                <div className="flex items-center justify-center flex-col gap-3 w-full">
                    <PiDetective className="size-15" />
                    <h1 className="font-gfbold text-2xl">Project Not Found</h1>
                </div>
            }
        </section>
    );
}

function ProjectCard({ project }: { project: Project }) {
    return (
        <div className="group transition-all duration-300">
            <div className="flex flex-col gap-4">
                <div className="relative overflow-hidden rounded-xl w-full h-50">
                    <Image
                        src={project.image}
                        alt={project.name ?? "Project image"}
                        fill
                        className="object-cover scale-105 group-hover:brightness-50 group-hover:scale-110 transition-all duration-300"
                    />
                    {/* <div className="absolute bottom-0 z-2 flex items-center justify-between p-3">
                        <div className="bg-muted/50 cursor-pointer opacity-0 group-hover:opacity-100 transition-all ease-in-out duration-300 flex items-center gap-1 px-3 py-2 rounded-full">
                            <FaGithub />
                            <p className="text-xs">Code</p>
                        </div>
                    </div> */}
                </div>
                <div>
                    <p className="text-[12px] text-muted/80">{project.category}</p>
                    <h3 className="text-2xl font-gfbold">{project.name}</h3>
                </div>
                <p className="text-sm text-muted/80">{project.description}</p>
                <div className="flex flex-wrap gap-1.5">
                    {project.tech.map((tag) => (
                        <span key={tag} className="text-xs w-fit py-2 px-4 rounded-xl font-mono bg-white/10">
                            {tag}
                        </span>
                    ))}
                </div>
                <div className="flex items-center gap-3 mt-1">
                    {project.githubLink && (
                        <a
                            href={project.githubLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-2 text-sm font-semibold bg-surface-container hover:bg-surface-container-high text-paper border border-board-line px-5 py-2.5 rounded-lg transition-all"
                        >
                            <FaGithub className="text-lg" /> Repository
                        </a>
                    )}
                    {project.demo_link && (
                        <a
                            href={project.demo_link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-2 text-sm font-semibold bg-primary hover:bg-primary/90 text-board px-5 py-2.5 rounded-lg transition-all"
                        >
                            <FaGlobe className="text-lg" /> Live Demo
                        </a>
                    )}
                    {project.link && (
                        <a
                            href={project.link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-2 text-sm font-semibold bg-copper hover:bg-copper-light text-board px-5 py-2.5 rounded-lg transition-all"
                        >
                            <BsBoxSeamFill className="text-lg" /> Magisk Module
                        </a>
                    )}
                    <Link href={`/projects/${project.id}`} className="flex items-center gap-2 text-sm font-semibold bg-primary hover:bg-primary/90 text-board px-5 py-2.5 rounded-lg transition-all">
                        <BiDetail className="text-lg" />
                        <p>Detail</p>
                    </Link>
                </div>
            </div>
        </div>
    );
}