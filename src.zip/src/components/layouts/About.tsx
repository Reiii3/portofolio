import Tag from "../ui/Tag";

export default function About() {
  return (
    <section id="tentang" className="border-b border-board-line/70">
      <div className="mx-auto max-w-6xl px-6 py-20 md:px-10 md:py-28">
        <Tag>
          <p className="font-medium text-md">Tentang Saya</p>
        </Tag>
        <h2 className="mt-4 max-w-2xl text-2xl font-semibold leading-snug text-paper sm:text-3xl md:text-4xl">
            Saya membangun tools system android dengan cara melakukan configurasi pada system untuk mengoptimalkan performa
        </h2>
        <div className="mt-8 grid gap-8 md:grid-cols-2">
          <p className="text-sm leading-relaxed text-muted/70 md:text-base">
            saya adalah siswa kelas 11 jurusan Rekayasa Perangkat Lunak,
            mengerjakan proyek dari front-end web dengan React dan Next.js,
            sampai eksperimen di sisi Android — termasuk modifikasi
            environment root dengan KernelSU dan pengembangan aplikasi native
            dengan Kotlin serta Jetpack Compose.
          </p>
          <p className="text-sm leading-relaxed text-muted/70 md:text-base">
            Ada banyak bahasa Program yang sudah saya pelajari terutama yang paling sering saya gunakan yaitu Bash dan Javascript, penggunaan kedua bahasa itu saya gunakan untuk membuat
            sebuah plugin Aplikasi Manager Android Seperti KernelSU (ROOT Manager) dan AxManager (No Root Manager), dengan menggunakan antarmuka berbasis web app saya dapat mengintegrasikan
            bahasa bash ini melewati APi bawaan dari KernelSU yang di Gunakan di AxManager juga dengan ini user dapat dengan mudah melakukan Configurasi System Android lebih lanjut dengan mudah
            dan cepat. dan diantara lain bahasa program yaang sudah saya pelajari seperti Java, Kotlin, Typescript, Python, dan ada juga Framework Seperti React, Next.js, TailwindCSS, Vite dan Jetpack Compose
          </p>
        </div>
      </div>
    </section>
  );
}
