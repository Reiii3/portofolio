import About from "@/components/layouts/About";
import Hero from "@/components/layouts/Hero";
import StackMarquee from "@/components/layouts/StackMarquee";

export default function Home() {
  return (
    <div>
      <Hero />
      <StackMarquee />
      <About />
    </div>
  );
}
